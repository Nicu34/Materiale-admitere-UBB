#pragma once
//#include "DynamicVector.h"
#include "Human.h"
#include <vector>

class BeFriendList
{
private:
	//DynamicVector<Human> friendsList;
	std::vector<Human> friendsList;
	int currentPos;

public:
	BeFriendList();
	~BeFriendList();

	void addFriend(const Human& s);
	Human currentHuman();
	void start();
	void next();
	std::string getHumanInfo();

	bool isEmpty();
	std::vector<Human> getAll() { return this->friendsList; }
	
};

