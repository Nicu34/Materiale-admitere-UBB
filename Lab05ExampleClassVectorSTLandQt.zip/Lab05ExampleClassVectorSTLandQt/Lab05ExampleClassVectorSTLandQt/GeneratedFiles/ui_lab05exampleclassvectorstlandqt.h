/********************************************************************************
** Form generated from reading UI file 'lab05exampleclassvectorstlandqt.ui'
**
** Created by: Qt User Interface Compiler version 5.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LAB05EXAMPLECLASSVECTORSTLANDQT_H
#define UI_LAB05EXAMPLECLASSVECTORSTLANDQT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Lab05ExampleClassVectorSTLandQtClass
{
public:
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QWidget *centralWidget;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *Lab05ExampleClassVectorSTLandQtClass)
    {
        if (Lab05ExampleClassVectorSTLandQtClass->objectName().isEmpty())
            Lab05ExampleClassVectorSTLandQtClass->setObjectName(QStringLiteral("Lab05ExampleClassVectorSTLandQtClass"));
        Lab05ExampleClassVectorSTLandQtClass->resize(600, 400);
        menuBar = new QMenuBar(Lab05ExampleClassVectorSTLandQtClass);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        Lab05ExampleClassVectorSTLandQtClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(Lab05ExampleClassVectorSTLandQtClass);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        Lab05ExampleClassVectorSTLandQtClass->addToolBar(mainToolBar);
        centralWidget = new QWidget(Lab05ExampleClassVectorSTLandQtClass);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        Lab05ExampleClassVectorSTLandQtClass->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(Lab05ExampleClassVectorSTLandQtClass);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        Lab05ExampleClassVectorSTLandQtClass->setStatusBar(statusBar);

        retranslateUi(Lab05ExampleClassVectorSTLandQtClass);

        QMetaObject::connectSlotsByName(Lab05ExampleClassVectorSTLandQtClass);
    } // setupUi

    void retranslateUi(QMainWindow *Lab05ExampleClassVectorSTLandQtClass)
    {
        Lab05ExampleClassVectorSTLandQtClass->setWindowTitle(QApplication::translate("Lab05ExampleClassVectorSTLandQtClass", "Lab05ExampleClassVectorSTLandQt", 0));
    } // retranslateUi

};

namespace Ui {
    class Lab05ExampleClassVectorSTLandQtClass: public Ui_Lab05ExampleClassVectorSTLandQtClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LAB05EXAMPLECLASSVECTORSTLANDQT_H
