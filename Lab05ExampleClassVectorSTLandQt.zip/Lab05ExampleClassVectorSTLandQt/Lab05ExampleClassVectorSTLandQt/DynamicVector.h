#pragma once
#include "Human.h"

//typedef Human TElement;
template <typename TElement>

class DynamicVector
{
private:
	TElement* elems;
	int size;
	int capacity;

public:
	// default constructor 
	DynamicVector(int capacity = 5);

	// copy constructor 
	DynamicVector(const DynamicVector& v);
	~DynamicVector();

	// Adds an element 
	void add(TElement e);

	
	TElement& operator[](int pos);

	int getSize() const;
	TElement* getAllElems() const;

private:
	// Resizes the current DynamicVector by given factor
	void resize(int factor = 2);
};

template <typename TElement>
DynamicVector<TElement>::DynamicVector(int capacity)
{
	this->size = 0;
	this->capacity = capacity;
	this->elems = new TElement[capacity];
}

template <typename TElement>
DynamicVector<TElement>::DynamicVector(const DynamicVector& v)
{
	this->size = v.size;
	this->capacity = v.capacity;
	this->elems = new TElement[this->capacity];
	for (int i = 0; i < this->size; i++)
		this->elems[i] = v.elems[i];
}
template <typename TElement>
DynamicVector<TElement>::~DynamicVector()
{
	delete[] this->elems;
}

template <typename TElement>
void DynamicVector<TElement>::add(TElement e)
{
	if (this->size == this->capacity)
		this->resize();

	this->elems[this->size] = e;
	this->size++;
}

template<typename TElement>
TElement& DynamicVector<TElement>::operator[](int pos) {
	return this->elems[pos];
}

template <typename TElement>
void DynamicVector<TElement>::resize(int factor)
{
	this->capacity *= factor; //the new capacity

	TElement* els = new TElement[this->capacity];
	for (int i = 0; i < this->size; i++)
		this->elems[i] = els[i];

	delete[] this->elems;
	elems = els;
}

template <typename TElement>
TElement* DynamicVector<TElement>::getAllElems() const 
{
	return this->elems;
}
template <typename TElement>
int DynamicVector<TElement>::getSize() const
{
	return this->size;
}