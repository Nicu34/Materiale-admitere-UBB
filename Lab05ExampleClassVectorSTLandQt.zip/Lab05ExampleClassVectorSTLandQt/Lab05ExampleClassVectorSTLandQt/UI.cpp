#include "UI.h"
#include <string>

using namespace std;


void UI::printRepositoryMenu()
{
	cout << "Possible commands: " << endl;
	cout << "\t 1 - Add human." << endl;
	cout << "\t 2 - Display all humans." << endl;
	cout << "\t ----------------------." << endl;
	cout << "\t 3 - Add a human to BeFriendlist." << endl;
	cout << "\t 4 - ShowQuality-first." << endl;
	cout << "\t 5 - Next." << endl;
	

	cout << "\t 0 - exit." << endl;
}


void UI::addHumanToRepo()
{
	cout << "Enter human's name: "<<endl;
	std::string name;
	getline(cin, name);
	double age = 0;
	cout << "Enter age: " << endl;
	cin >> age;
	cin.ignore();
	cout << "Enter human's homepage link: " << endl;
	std::string homepageLink;
	getline(cin, homepageLink);
	

	this->ctrl.addHumanToRepository(name, age, homepageLink);
}

void UI::displayAllHumansRepo()
{
	//DynamicVector<Human> v = this->ctrl.getRepo().getHumans();
	vector<Human> v = this->ctrl.getRepo().getHumans();

	//Human* humans = v.getAllElems();
	//if (humans == NULL)
//		return;
	if (v.size() == 0)
	{
		cout << "There are no humans in the repository." << endl;
		return;
	}
	cout << "..................................." << endl;
	cout << "Humans ... " << endl;
	for (auto h : v)
	{
		cout << "Human " << h.getName() << " with age " << h.getAge() << " and homepage " << h.getHomepageLink() << "." << endl;
	}
	/*
	for (int i = 0; i < v.getSize(); i++)
	{
		Human h = humans[i];		
		cout <<"Human "<< h.getName() << " with age " << h.getAge() << " and homepage " << h.getHomepageLink() << "."<<endl;
	}*/
	cout << "..................................." << endl;
	
}

void UI::addHumanToBeFriendlist()
{
	cout << "Enter the name of human: ";
	std::string name;
	getline(cin, name);

	// search for the human name in the repository
	Human h = (this->ctrl.getRepo()).findByName(name);
	if (h.getName() == "")
	{
		cout << "There are no humans with the given name in the repository." << endl;
		return;
	}

	this->ctrl.addHumanToBeFiendList(h);
	cout << "Human  " <<h.getName()<<" added."<< endl;
}
void UI::run()
{
	while (true)
	{
		UI::printRepositoryMenu();
		int commandRepo{ 0 };
		cout << "Input the command: ";
		cin >> commandRepo;
		cin.ignore();
		if (commandRepo == 0)
			break;
		switch (commandRepo)
		{
		case 1:
			this->addHumanToRepo();
			break;
		case 2:
			this->displayAllHumansRepo();
			break;
		case 3:
			this->addHumanToBeFriendlist();
			break;
		case 4:
		{
			if (this->ctrl.getFriendList().isEmpty())
			{
				cout << "Nothing to see, the beFriendlist is empty." << endl;
				continue;
			}
			this->ctrl.startBeFriendlist();
			Human h = this->ctrl.getFriendList().currentHuman();
			cout << "Now showing quality: " << h.getName() << " " << h.getAge() << " " << h.getHomepageLink() << endl;
			break;
		}
		case 5:
		{
			if (this->ctrl.getFriendList().isEmpty())
			{
				cout << "Nothing to see, the beFriendlist is empty." << endl;
				continue;
			}
			this->ctrl.nextBeFriendlist();
			Human hNext = this->ctrl.getFriendList().currentHuman();
			cout << "Now showing quality: " << hNext.getName() << " " << hNext.getAge() << " " << hNext.getHomepageLink() << endl;
			break;
		}
		}
	}
}
