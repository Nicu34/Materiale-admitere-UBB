#pragma once
#include <string>
#include "Human.h"
#include <vector>


class HumanException
{
private:
	std::vector<std::string> errors;

public:
	HumanException(std::vector<std::string> _errors);
	std::vector<std::string> getErrors() const;
	std::string getErrorsAsString() const;
};


#pragma once
