#include "Repository.h"
#include <string>



using namespace std;

Repository::Repository()
{
	
}

void Repository::addHuman(const Human& h)
{
	//this->humans.add(h);		
	this->humans.push_back(h);
}

Human Repository::findByName(const std::string& name)
{
	/*
	Human* humansInVector = this->humans.getAllElems();
	if (humansInVector== NULL)
		return Human{};

	for (int i = 0; i < this->humans.getSize(); i++)
	{
		Human h = humansInVector[i];
		if (h.getName() == name)
			return h;
	}

	return Human{};
	*/

	for (auto h : this->humans)
	{
		if (h.getName() == name )
			return h;
	}

	return Human{};

}
