#ifndef BeFriendListQt_H
#define BeFriendListQt_H

#include <QtWidgets/QMainWindow>
#include "Controller.h"
#include <QListWidget>
#include <QFormLayout>
#include <QLineEdit>
#include <QPushButton>
#include <QLabel>

class BeFriendListQt : public QWidget //public QMainWindow
{
	Q_OBJECT

public:
	BeFriendListQt(Controller& c, QWidget *parent = 0);
	~BeFriendListQt();

private:
	Controller& ctrl;
	std::vector<Human> currentHumansInRepoList;

	QListWidget* repoList;
	QLineEdit* nameEdit;
	QLineEdit* ageEdit;	
	QLineEdit* linkEdit;

	QPushButton* addButton;
	QPushButton* moveOneHumanButton;
	
	QListWidget* beFriendList;
	
	void initGUI();
	void populateRepoList();
	void populateBeFriendList();
	int getRepoListSelectedIndex();

	void connectSignalsAndSlots();

private slots:
	// When an item in the list is clicked, the text boxes get filled with the item's information
	void listItemChanged();

	void addNewHuman();
		
	void moveHumanToBeFriendList();
	
};

#endif 
