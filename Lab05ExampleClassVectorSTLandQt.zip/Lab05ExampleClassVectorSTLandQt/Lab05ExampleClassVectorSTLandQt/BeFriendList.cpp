#include "BeFriendList.h"
using namespace std;


BeFriendList::BeFriendList()
{
	this->currentPos = 0;
}


BeFriendList::~BeFriendList()
{
}

void BeFriendList::addFriend(const Human& s)
{
	//this->friendsList.add(s);
	this->friendsList.push_back(s);
}
Human BeFriendList::currentHuman()
{
	return friendsList[currentPos];
}
void BeFriendList::start()
{
	if (friendsList.size() == 0)
		return;
	friendsList[0].showQuality();
}
void BeFriendList::next()
{
	currentPos += 1;
	if (currentPos >= friendsList.size())
		currentPos = 0;
	friendsList[currentPos].showQuality();
}
string BeFriendList::getHumanInfo()
{
	string s;
	s = friendsList[currentPos].getName();
	return s;
}


bool BeFriendList:: isEmpty()
{
	return this->friendsList.size() == 0;
}