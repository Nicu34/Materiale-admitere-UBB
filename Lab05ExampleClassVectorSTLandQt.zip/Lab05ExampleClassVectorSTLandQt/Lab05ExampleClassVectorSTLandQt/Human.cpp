#include "Human.h"

#include <Windows.h>


Human::Human() : name(""), age(0), homepageLink("") {}

Human::Human(const std::string &name, double age,const std::string &homepageLink)
{
	this->name = name;
	this->age = age;
	this->homepageLink = homepageLink;
	
}

void Human::showQuality()
{
	ShellExecuteA(NULL, NULL, "chrome.exe", this->homepageLink.c_str(), NULL, SW_MAXIMIZE);
}