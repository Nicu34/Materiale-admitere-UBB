
#pragma once
#include <iostream>


class Human{

private:
	std::string name;
	double age;
	std::string homepageLink;

public:
	// default constructor
	Human();
	// constructor with parameters
	Human(const std::string& name, double age, const std::string& homepageLink);

	std::string getName() const { return name; }
	double getAge() const { return age; }
	std::string getHomepageLink() const { return homepageLink; }

	void showQuality();
};