#pragma once
#include "Human.h"
//#include "DynamicVector.h"
#include <vector>

class Repository
{
private:
	//DynamicVector<Human> humans;
	std::vector<Human> humans;
public:
	Repository();

	void addHuman(const Human& h);

	Human findByName(const std::string& name);

	//DynamicVector<Human> getHumans() const { return humans; }
	std::vector<Human> getHumans() const { return humans; }
};