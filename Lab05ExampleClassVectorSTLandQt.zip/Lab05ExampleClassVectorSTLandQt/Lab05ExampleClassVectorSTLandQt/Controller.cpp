#include "Controller.h"


void Controller::addHumanToRepository(const std::string& name,  double age, const std::string& homepageLink)
{
	Human h{ name, age, homepageLink };
	
	this->repo.addHuman(h);
}

void Controller::addHumanToBeFiendList(const Human& human)
{
	this->friendList.addFriend(human);
}

void Controller::startBeFriendlist()
{
	this->friendList.start();
}
void Controller::nextBeFriendlist()
{
	this->friendList.next();
}