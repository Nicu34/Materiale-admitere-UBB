#include "lab05exampleclassvectorstlandqt.h"

Lab05ExampleClassVectorSTLandQt::Lab05ExampleClassVectorSTLandQt(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
}

Lab05ExampleClassVectorSTLandQt::~Lab05ExampleClassVectorSTLandQt()
{

}
