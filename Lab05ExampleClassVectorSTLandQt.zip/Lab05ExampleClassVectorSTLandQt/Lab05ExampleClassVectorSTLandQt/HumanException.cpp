#include "HumanException.h"

using namespace std;

HumanException::HumanException(std::vector<std::string> _errors) : errors{ _errors }
{
}

std::vector<std::string> HumanException::getErrors() const
{
	return this->errors;
}

std::string HumanException::getErrorsAsString() const
{
	string err;
	for (auto e : this->errors)
		err += e;
	return err;
}
