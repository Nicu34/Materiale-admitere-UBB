#include "lab05exampleclassvectorstlandqt.h"
#include <QtWidgets/QApplication>

#include "BeFriendListQt.h"




int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	//Lab05ExampleClassVectorSTLandQt w;
	//w.show();
	
	Repository repo;
	Controller ctrl(repo);
	//UI ui(ctrl);
	//ui.run();

	BeFriendListQt w{ ctrl };	

	
	w.show();
	
	return a.exec();
}
