#include "BeFriendListQt.h"
#include <vector>
#include "Human.h"
#include "HumanException.h"
#include <QMessageBox>


BeFriendListQt::BeFriendListQt(Controller& c, QWidget *parent) : ctrl{ c }, QWidget { parent }
{
	this->initGUI();
	this->currentHumansInRepoList = this->ctrl.getAllHumans();
	this->populateRepoList();
}

BeFriendListQt::~BeFriendListQt()
{

}

void BeFriendListQt::initGUI()
{
	//General layout of the window
	QHBoxLayout* layout = new QHBoxLayout{this};

	QWidget* leftWidget = new QWidget{};
	QVBoxLayout* leftSide = new QVBoxLayout{ leftWidget };

	// list
	this->repoList = new QListWidget{};
	// set the selection model
	this->repoList->setSelectionMode(QAbstractItemView::SingleSelection);
	
	// human data
	QWidget* humanDataWidget = new QWidget{};
	QFormLayout* formLayout = new QFormLayout{humanDataWidget};
	this->nameEdit = new QLineEdit{};
	this->ageEdit = new QLineEdit{};	
	this->linkEdit = new QLineEdit{};

	formLayout->addRow("&Name:", nameEdit);
	formLayout->addRow("&Age:", ageEdit);	
	formLayout->addRow("&Link:", linkEdit);

	// buttons
	QWidget* buttonsWidget = new QWidget{};
	QGridLayout* gridLayout = new QGridLayout{ buttonsWidget };
	this->addButton = new QPushButton("Add");
	
	gridLayout->addWidget(addButton, 0, 0);
	
	// add everything to the left layout
	leftSide->addWidget(new QLabel{"All humans"});
	leftSide->addWidget(repoList);
	leftSide->addWidget(humanDataWidget);
	leftSide->addWidget(buttonsWidget);

	// middle component: just one button - to add the humans from the reposiotory to the friendlist
	QWidget* middleWidget = new QWidget{};
	QVBoxLayout* vLayoutMiddle = new QVBoxLayout{ middleWidget };
	this->moveOneHumanButton = new QPushButton{ ">> Move one" };
	QWidget* upperPart = new QWidget{};	
	QVBoxLayout* vLayoutUpperPart = new QVBoxLayout{ upperPart };
	vLayoutUpperPart->addWidget(this->moveOneHumanButton);
	vLayoutMiddle->addWidget(upperPart);
	

	// right component: the BeFriendList
	QWidget* rightWidget = new QWidget{};
	QVBoxLayout* rightSide = new QVBoxLayout{ rightWidget };

	// BeFriendList
	beFriendList = new QListWidget{};

	// two buttons
	QWidget* seeQualityListButtonsWidget = new QWidget{};
	QHBoxLayout* seeQualityListButtonsLayout = new QHBoxLayout{ seeQualityListButtonsWidget };
	seeQualityListButtonsLayout->addWidget(new QPushButton{ "&SeeQuality" });
	seeQualityListButtonsLayout->addWidget(new QPushButton{ "&Next" });

	// add everything to the right layout
	rightSide->addWidget(new QLabel{ "BeFriendList" });
	rightSide->addWidget(beFriendList);
	rightSide->addWidget(seeQualityListButtonsWidget);

	// add the three layouts to the main layout
	layout->addWidget(leftWidget);
	layout->addWidget(middleWidget);
	layout->addWidget(rightWidget);

	// connect the signals and slots
	this->connectSignalsAndSlots();
}

void BeFriendListQt::connectSignalsAndSlots()
{
	// add a connection: function listItemChanged() will be called when an item in the list is selected
	QObject::connect(this->repoList, SIGNAL(itemSelectionChanged()), this, SLOT(listItemChanged()));

	// add button connections
	QObject::connect(this->addButton, SIGNAL(clicked()), this, SLOT(addNewHuman()));
	
	QObject::connect(this->moveOneHumanButton, SIGNAL(clicked()), this, SLOT(moveHumanToBeFriendList()));
	
}

void BeFriendListQt::populateRepoList()
{
	// clear the list, if there are elements in it
	if (this->repoList->count() > 0)
		this->repoList->clear();

	for (auto s : this->currentHumansInRepoList)
	{
		QString itemInList = QString::fromStdString(s.getName());
		this->repoList->addItem(itemInList);
	}
	
	// set the selection on the first item in the list
	if (this->currentHumansInRepoList.size() > 0)
		this->repoList->setCurrentRow(0);
}

void BeFriendListQt::populateBeFriendList()
{
	// clear the list, if there are elements in it
	
	if (this->beFriendList->count() > 0)
		this->beFriendList->clear();

	for (auto s : this->ctrl.getHumansFromFriendList())
	{
		QString itemInList = QString::fromStdString(s.getName());
		this->beFriendList->addItem(itemInList);
	}
	
}
int BeFriendListQt::getRepoListSelectedIndex()
{
	if (this->repoList->count() == 0)
		return -1;

	// get selected index
	QModelIndexList index = this->repoList->selectionModel()->selectedIndexes();
	if (index.size() == 0)
	{
		this->nameEdit->clear();
		this->ageEdit->clear();		
		this->linkEdit->clear();
		return -1;
	}

	int idx = index.at(0).row();
	return idx;
}

void BeFriendListQt::listItemChanged()
{
	int idx = this->getRepoListSelectedIndex();
	if (idx == -1)
		return;
	
	std::vector<Human> humans = this->currentHumansInRepoList;
	
	// get the song at the selected index
	if (idx >= humans.size())
		return;
	Human s = humans[idx];

	this->nameEdit->setText(QString::fromStdString(s.getName()));
	this->ageEdit->setText(QString::fromStdString(s.getName()));
	
	this->linkEdit->setText(QString::fromStdString(s.getHomepageLink()));
}

void BeFriendListQt::addNewHuman()
{
	std::string name = this->nameEdit->text().toStdString();
	double age = this->ageEdit->text().toDouble();
	
	std::string source = this->linkEdit->text().toStdString();

	try
	{
		this->ctrl.addHumanToRepository(name, age, source);
		// refresh the list
		this->currentHumansInRepoList = this->ctrl.getAllHumans();
		this->populateRepoList();
	}
	catch (HumanException& e)
	{
		QMessageBox messageBox;
		messageBox.critical(0, "Error", QString::fromStdString(e.getErrorsAsString()));
	}
	
}


void BeFriendListQt::moveHumanToBeFriendList()
{
	int idx = this->getRepoListSelectedIndex();
	if (idx == -1 || idx >= this->currentHumansInRepoList.size())
		return;

	const Human& s = this->currentHumansInRepoList[idx];
	this->ctrl.addHumanToBeFiendList(s);
	this->populateBeFriendList();
}
