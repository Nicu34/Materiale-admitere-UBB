#ifndef LAB05EXAMPLECLASSVECTORSTLANDQT_H
#define LAB05EXAMPLECLASSVECTORSTLANDQT_H

#include <QtWidgets/QMainWindow>
#include "ui_lab05exampleclassvectorstlandqt.h"

class Lab05ExampleClassVectorSTLandQt : public QMainWindow
{
	Q_OBJECT

public:
	Lab05ExampleClassVectorSTLandQt(QWidget *parent = 0);
	~Lab05ExampleClassVectorSTLandQt();

private:
	Ui::Lab05ExampleClassVectorSTLandQtClass ui;
};

#endif // LAB05EXAMPLECLASSVECTORSTLANDQT_H
