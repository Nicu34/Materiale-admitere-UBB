#pragma once
#include "Repository.h"
#include "BeFriendList.h"

class Controller
{
private:
	Repository repo;
	BeFriendList friendList;
public:
	Controller(const Repository& r) : repo(r) {}

	Repository getRepo() const { return repo; }
	std::vector<Human> getAllHumans() const { return this->repo.getHumans(); }
	std::vector<Human> getHumansFromFriendList() { return this->friendList.getAll(); }

	BeFriendList getFriendList() const { return friendList; }

	// Adds a human with the given data to the humans repository.
	void addHumanToRepository(const std::string& name, double age, const std::string& homepageLink);

	void addHumanToBeFiendList(const Human& human);
	void startBeFriendlist();
	void nextBeFriendlist();

};

